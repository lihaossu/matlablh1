function graphic_demo_plot
% For the MLP demo presentation, an M file that does some
% stuff in painters to prove a point.
  
  contourf(peaks(20));
  box on;
  title('Contour of peaks');