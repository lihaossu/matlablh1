clear all; close all; clc;

%% Load File

% Symmetric

Symmetric = [48.5 48.6 48.7 48.7 48.4 48.5 48.6 48.4 48.7 


%% Figure

Iter = 3:2:25;

bar(Iter,Data)
axis([2 26 0 100])
xlabel('Number of k');
ylabel('Error Probability (%)');
grid on
legend('Decision Level Error','Conventional kNN','Conventional kNN w/ Fuzzy','Advanced kNN','Advacned kNN w/ Fuzzy');
